<?php

class Lamp{
    private $idlamp;
    private $name;
    private $encendido;
    private $modelo;
    private $potencia;
    private $zona;

    public function __construct($idLamp, $name, $encendido, $modelo, $potencia, $zona) {
        $this->idLamp = $idLamp;
        $this->name = $name;
        $this->encendido = $encendido;
        $this->modelo = $modelo;
        $this->potencia = $potencia;
        $this->zona = $zona;
    }
    
    public function getIdlamp()
    {
        return $this->idlamp;
    }
    
    public function getName()
    {
        return $this->name;
    }

    public function getEncendido()
    {
        return $this->encendido;
    }

    public function getModelo()
    {
        return $this->modelo;
    }

    public function getPotencia()
    {
        return $this->potencia;
    }

    public function getZona()
    {
        return $this->zona;
    }

    public function setEncendido($encendido): self
    {
        $this->encendido = $encendido;

        return $this;
    }
}
?>