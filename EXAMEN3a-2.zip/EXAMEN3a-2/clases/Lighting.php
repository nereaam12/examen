<?php

class Lighting extends Connection{

    public function __construct()
    {
        parent::__construct();
    }

    public function getAllLamps(){
        $lamps = [];

        $sql = "SELECT lamps.lamp_id, lamps.lamp_name, lamp_on, lamp_models.model_part_number,lamp_models.model_wattage,zones.zone_name 
                FROM lamps INNER JOIN lamp_models ON lamps.lamp_model=lamp_models.model_id 
                INNER JOIN zones ON amps.lamp_zone = zones.zone_id ORDER BY lamps.lamp_id;";

        $stmt = $this->conn->prepare($sql);

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lamp = new Lamp(
                $row['lamp_id'],
                $row['lamp_name'],
                $row['lamp_on'],
                $row['model_part_number'],
                $row['model_wattage'],
                $row['zone_name']
            );
            $lamps[] = $lamp;
        }
        return $lamps;  
    }

    public function drawLampsList($zona){
        $lamps = $this->getAllLamps($zona);

            foreach ($lamps as $lamp) {
                /*echo "<div class='center'. $lamps['lamp_id'] . </div>
                        <div class='center'. $lamps['lamp_name] . </div>
                        <div class='center'. $lamps['lamp_on'] . </div>
                        <div class='center'. $lamps['model_part_number] . </div>
                        <div class= 'center' .$lamps['model_wattage] . </div>
                        <div class='center'. $lamps['zone_name] . </div>";*/
                        echo $lamps['lamp_id'];
                        
                if ($lamps->encendido()) {
                    echo "<img src='bulb-icon-on.png' alt='Encendida';'>";
                } else {
                    echo "<img src='bulb-icon-off.png' alt='Apagada';'>";
                }
        
                echo "</div>"; 
        }
    }
}



?>

